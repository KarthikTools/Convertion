const express = require('express');
const bodyParser = require('body-parser');
const jwt = require('jsonwebtoken');
const app = express();
const port = process.env.PORT || 3000; // Allow port to be set via environment variable

// Middleware
app.use(bodyParser.json());

// Simple in-memory database
const users = {};
let userIdCounter = 1000;

// Log all requests for debugging
app.use((req, res, next) => {
  console.log(`${new Date().toISOString()} - ${req.method} ${req.url}`);
  next();
});

// Add rate limiting headers for testing
app.use((req, res, next) => {
  res.setHeader('X-RateLimit-Limit', '100');
  res.setHeader('X-RateLimit-Remaining', String(Math.floor(Math.random() * 100)));
  next();
});

// JWT secret for token generation
const JWT_SECRET = process.env.JWT_SECRET || 'your-secret-key';

// ROUTES

// 1. User Registration
app.post('/register', (req, res) => {
  const { name, email, password, role } = req.body;
  
  // Check if user already exists
  const existingUser = Object.values(users).find(u => u.email === email);
  
  if (existingUser) {
    return res.status(200).json({
      message: "User already exists",
      userId: existingUser.id
    });
  }
  
  // Create new user
  const userId = String(userIdCounter++);
  const newUser = {
    id: userId,
    name,
    email,
    password, // In a real app, this would be hashed
    role,
    createdAt: new Date().toISOString(),
    profileStatus: 'pending',
    isActive: true,
    lastLogin: null
  };
  
  users[userId] = newUser;
  
  res.status(201).json({
    message: "User registered successfully",
    userId
  });
});

// 2. Get User Details
app.get('/user/:id', (req, res) => {
  const userId = req.params.id;
  const user = users[userId];
  
  if (!user) {
    return res.status(404).json({
      error: "User not found"
    });
  }
  
  // Don't send the password in the response
  const { password, ...userDetails } = user;
  
  res.json(userDetails);
});

// 3. Validate User Profile
app.post('/validate-profile', (req, res) => {
  const { userId, registrationTimestamp, profileStatus, role, email } = req.body;
  const user = users[userId];
  
  if (!user) {
    return res.status(404).json({
      error: "User not found"
    });
  }
  
  // Update user profile status
  user.profileStatus = 'validated';
  user.updatedAt = new Date().toISOString();
  
  res.json({
    valid: true,
    validationMessage: "Profile validation successful",
    userId
  });
});

// 4. Get Auth Token
app.post('/getToken', (req, res) => {
  const { email, password } = req.body;
  
  const user = Object.values(users).find(u => u.email === email && u.password === password);
  
  if (!user) {
    return res.status(401).json({
      error: "Invalid credentials"
    });
  }
  
  // Update last login
  user.lastLogin = new Date().toISOString();
  
  // Generate JWT token
  const token = jwt.sign(
    { userId: user.id, email: user.email, role: user.role }, 
    JWT_SECRET, 
    { expiresIn: '1h' }
  );
  
  res.json({
    token,
    expiresIn: 3600, // 1 hour in seconds
    userId: user.id
  });
});

// 5. Authenticated Resource (requires token)
app.get('/authenticated-resource', authenticateToken, (req, res) => {
  res.json({
    authenticated: true,
    userId: req.user.userId,
    message: "You have access to this protected resource",
    timestamp: new Date().toISOString()
  });
});

// 6. DB Validation
app.get('/db-validate', (req, res) => {
  const userId = req.query.id;
  const user = users[userId];
  
  if (!user) {
    return res.status(404).json({
      error: "User not found in database"
    });
  }
  
  res.json({
    exists: true,
    userData: {
      id: user.id,
      name: user.name,
      email: user.email,
      role: user.role,
      profileStatus: user.profileStatus,
      createdAt: user.createdAt,
      lastLogin: user.lastLogin,
      isActive: user.isActive
    }
  });
});

// 7. DB Assertions
app.post('/db-assertions', (req, res) => {
  const { userId, assertions } = req.body;
  const user = users[userId];
  
  if (!user) {
    return res.status(404).json({
      error: "User not found in database"
    });
  }
  
  const assertionResults = [];
  let passedAssertions = 0;
  const failedAssertions = [];
  
  assertions.forEach(assertion => {
    const { field, expectedValue, operator } = assertion;
    const fieldValue = user[field];
    let passed = false;
    let message = '';
    
    switch (operator) {
      case 'equals':
        passed = fieldValue === expectedValue;
        message = passed ? `${field} equals expected value` : `${field} does not equal expected value`;
        break;
      case 'exists':
        passed = fieldValue !== undefined && fieldValue !== null;
        message = passed ? `${field} exists` : `${field} does not exist`;
        break;
      case 'notEmpty':
        passed = fieldValue && fieldValue.length > 0;
        message = passed ? `${field} is not empty` : `${field} is empty`;
        break;
      default:
        message = `Unknown operator: ${operator}`;
        passed = false;
    }
    
    if (passed) {
      passedAssertions++;
    } else {
      failedAssertions.push({
        field,
        expectedValue,
        actualValue: fieldValue,
        operator
      });
    }
    
    assertionResults.push({
      name: `${field} ${operator}`,
      passed,
      message
    });
  });
  
  res.json({
    assertionsPassed: failedAssertions.length === 0,
    passedAssertions,
    totalAssertions: assertions.length,
    failedAssertions,
    assertionDetails: assertionResults
  });
});

// 8. Health check endpoint
app.get('/health', (req, res) => {
  res.json({
    status: 'ok',
    uptime: process.uptime(),
    timestamp: new Date().toISOString()
  });
});

// Token authentication middleware
function authenticateToken(req, res, next) {
  const authHeader = req.headers['authorization'];
  const token = authHeader && authHeader.split(' ')[1];
  
  if (!token) {
    return res.status(401).json({
      error: "Authentication token required"
    });
  }
  
  jwt.verify(token, JWT_SECRET, (err, user) => {
    if (err) {
      return res.status(403).json({
        error: "Invalid or expired token"
      });
    }
    
    req.user = user;
    next();
  });
}

// Start the server
app.listen(port, '0.0.0.0', () => {
  console.log(`Mock API server running at http://0.0.0.0:${port}`);
  console.log('Available endpoints:');
  console.log('- POST /register');
  console.log('- GET /user/:id');
  console.log('- POST /validate-profile');
  console.log('- POST /getToken');
  console.log('- GET /authenticated-resource (requires token)');
  console.log('- GET /db-validate?id=userId');
  console.log('- POST /db-assertions');
  console.log('- GET /health');
}); 