#!/bin/bash

# Environment variables (customize as needed)
export PORT=3000
export JWT_SECRET="your-secure-jwt-secret-key-here"
export NODE_ENV="production"

# Start the server in the background
nohup node server.js > server.log 2>&1 &

# Save the process ID to a file
echo $! > server.pid

echo "Server started on port $PORT with PID $(cat server.pid)"
echo "Logs are being written to server.log" 