#!/bin/bash

if [ -f server.pid ]; then
    PID=$(cat server.pid)
    
    if ps -p $PID > /dev/null; then
        echo "Stopping server with PID $PID..."
        kill $PID
        echo "Server stopped"
    else
        echo "Server is not running with PID $PID"
    fi
    
    rm server.pid
else
    echo "PID file not found. Server might not be running."
    echo "Attempting to find and kill the process..."
    
    # Find and kill Node.js processes running server.js
    PIDS=$(ps aux | grep "[n]ode server.js" | awk '{print $2}')
    
    if [ -n "$PIDS" ]; then
        for pid in $PIDS; do
            echo "Killing process $pid..."
            kill $pid
        done
        echo "Server processes stopped"
    else
        echo "No server processes found"
    fi
fi 